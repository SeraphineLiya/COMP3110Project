public class asdf
{
    public void f();

    public void g();

    public void h();

    integerthisthingisawesome x;

    String s1;
}