package project;

import java.io.File;
import java.io.PrintWriter;
import java.util.List;

public class Main {

    public static void main(String[] args) throws Exception {

        // ⭐ If args[0] given -> use that folder, otherwise default to "new dataset"
        String folderName = (args.length >= 1) ? args[0] : "new dataset";

        // ⭐ Output file automatically placed inside the same folder
        String outputFile = folderName + "/output.txt";

        System.out.println("Processing folder: " + folderName);
        System.out.println("Writing results to: " + outputFile);

        LineMapper lm = new LineMapper();

        File folder = new File(folderName);
        File[] allFiles = folder.listFiles();

        if (allFiles == null) {
            System.out.println("ERROR: Folder not found → " + folderName);
            return;
        }

        // ⭐ Output writer
        PrintWriter out = new PrintWriter(outputFile);

        for (File file : allFiles) {

            String name = file.getName();

            // Only process files ending with _1.java
            if (!name.endsWith("_1.java"))
                continue;

            // Paths for version 1 and version 2
            String file1 = folderName + "/" + name;
            String file2 = folderName + "/" + name.replace("_1.java", "_2.java");

            File second = new File(file2);
            if (!second.exists())
                continue;

            // Read both versions
            List<String> a = lm.read(file1);
            List<String> b = lm.read(file2);

            // Compute line mappings
            List<LineMapping> mappings = lm.map(a, b);

            // ⭐ Print filename first (required by evaluator)
            out.println(name);

            // ⭐ Print mappings
            for (LineMapping m : mappings) {
                if (m.newLine == -1)
                    out.println(m.oldLine + " -> (deleted)");
                else
                    out.println(m.oldLine + " -> " + m.newLine);
            }

            out.println(); // blank line between files
        }

        out.close();
        System.out.println("DONE → Output saved in: " + outputFile);
    }
}
