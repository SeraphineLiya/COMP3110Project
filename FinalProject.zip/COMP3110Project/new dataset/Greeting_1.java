// simple greeting program
public class Greeting {

	public static void main(String[] args)
	{
		String name = "World";
		
		System.out.println("Hello, " + name + "!");
		System.out.println("Welcome to Java.");
	}
}
