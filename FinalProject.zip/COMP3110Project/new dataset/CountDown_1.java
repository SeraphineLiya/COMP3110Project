// countdown program
public class CountDown {

	public static void main(String[] args)
	{
		int start = 10;
		
		System.out.println("Counting down:");
		for(int i = start; i >= 0; i--) {
			System.out.println(i);
		}
		
		System.out.println("Blast off!");
	}
}
